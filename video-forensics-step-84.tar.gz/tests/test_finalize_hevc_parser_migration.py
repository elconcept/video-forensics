from __future__ import annotations

import json
from pathlib import Path

import pytest

from scripts.finalize_hevc_parser_migration import validate_gate


def gate(path: Path, *, passed: bool = True) -> None:
    ids = (
        "SOURCE_SHA256",
        "FFMPEG_CONTROL",
        "FIELD_MISMATCH_LIMIT",
        "COMPARABLE_RECORD_MINIMUM",
        "LEGACY_SEMANTIC_AGREEMENT",
        "RPS_COMPARISON_COMPLETE",
    )
    path.write_text(
        json.dumps(
            {
                "module": "hevc_migration_regression",
                "passed": passed,
                "legacy_removal_ready": passed,
                "cases": [
                    {
                        "passed": passed,
                        "checks": [
                            {"id": check_id, "passed": passed} for check_id in ids
                        ],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )


def test_accepts_fully_passing_gate(tmp_path: Path) -> None:
    path = tmp_path / "gate.json"
    gate(path)
    assert validate_gate(path)["legacy_removal_ready"] is True


def test_rejects_failed_gate(tmp_path: Path) -> None:
    path = tmp_path / "gate.json"
    gate(path, passed=False)
    with pytest.raises(ValueError, match="did not pass"):
        validate_gate(path)
