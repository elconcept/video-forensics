from pathlib import Path

pyproject = Path("pyproject.toml")
text = pyproject.read_text(encoding="utf-8")
entry = 'video-forensics-hevc-reference-compare = "video_forensics.native.hevc_reference_compare:main"\n'
if entry not in text:
    marker = "[project.scripts]\n"
    if marker not in text:
        raise SystemExit("Cannot find [project.scripts]")
    text = text.replace(marker, marker + entry, 1)
pyproject.write_text(text, encoding="utf-8")

stage = Path("src/video_forensics/native/hevc_migration_stage.py")
text = stage.read_text(encoding="utf-8")
import_line = "from video_forensics.native.hevc_reference_compare import run as run_reference_compare\n"
if import_line not in text:
    anchor = "from video_forensics.native.hevc_parser_authority import run as run_authority\n"
    if anchor not in text:
        raise SystemExit("Cannot find parser authority import")
    text = text.replace(anchor, anchor + import_line, 1)
needle = '''        authority = run_authority(
'''
if needle not in text:
    raise SystemExit("Cannot find authority call")
start = text.find(needle)
end = text.find("        result = {", start)
block = text[start:end]
if "run_reference_compare(" not in block:
    addition = '''        reference = run_reference_compare(
            annex_b,
            output / "reference_comparison",
            repository=repository,
            ffmpeg=ffmpeg,
            ffprobe=str(ffprobe),
            wrapper=wrapper,
            h265nal=h265nal,
            legacy_json=legacy_json,
            timeout=timeout,
        )
'''
    text = text[:end] + addition + text[end:]
text = text.replace(
    '            "authority_manifest": str(authority_root / "parser_authority.json"),\n',
    '            "authority_manifest": str(authority_root / "parser_authority.json"),\n'
    '            "reference_comparison_manifest": str(output / "reference_comparison" / "reference_comparison.json"),\n'
    '            "legacy_removal_ready": reference["migration_acceptance"]["ready_for_legacy_removal"],\n',
    1,
)
stage.write_text(text, encoding="utf-8")
