from pathlib import Path

segments = Path("src/video_forensics/tools/hevc_slice_segments.py")
text = segments.read_text(encoding="utf-8")
import_line = '''from video_forensics.tools.hevc_long_term_rps import (
    SpsLongTermReference,
    parse_slice_long_term_references,
)
'''
if "from video_forensics.tools.hevc_long_term_rps import" not in text:
    anchor = "from video_forensics.tools.hevc_short_term_rps import (\n"
    start = text.find(anchor)
    if start == -1:
        raise SystemExit("Cannot find short-term RPS import")
    end = text.find(")\n", start) + 2
    text = text[:end] + import_line + text[end:]

text = text.replace(
    "    short_term_rps: dict[str, object] | None\n",
    "    short_term_rps: dict[str, object] | None\n"
    "    long_term_rps: dict[str, object] | None\n",
    1,
)
text = text.replace(
    "    sps_rps: dict[int, list[ShortTermRPS]] | None = None,\n",
    "    sps_rps: dict[int, list[ShortTermRPS]] | None = None,\n"
    "    sps_long_term: dict[int, list[SpsLongTermReference]] | None = None,\n",
    1,
)

needle = '''            short_term_rps = available[short_term_ref_pic_set_idx].to_dict()

    return SliceSegmentHeader(
'''
replacement = '''            short_term_rps = available[short_term_ref_pic_set_idx].to_dict()

    long_term_rps = None
    if nal_type not in {19, 20}:
        available_long_term = (
            [] if sps_long_term is None else sps_long_term.get(sps.sps_id, [])
        )
        if available_long_term or getattr(sps, "long_term_ref_pics_present_flag", 0):
            parsed_long_term = parse_slice_long_term_references(
                reader,
                log2_max_poc_lsb=sps.log2_max_poc_lsb,
                sps_references=available_long_term,
            )
            parsed_long_term.pop("parsed_references")
            long_term_rps = parsed_long_term

    return SliceSegmentHeader(
'''
if needle not in text:
    raise SystemExit("Cannot find short-term RPS completion block")
text = text.replace(needle, replacement, 1)
text = text.replace(
    "        short_term_rps=short_term_rps,\n",
    "        short_term_rps=short_term_rps,\n"
    "        long_term_rps=long_term_rps,\n",
    1,
)
text = text.replace(
    "    sps_rps: dict[int, list[ShortTermRPS]] | None = None,\n) -> dict[str, object]:\n",
    "    sps_rps: dict[int, list[ShortTermRPS]] | None = None,\n"
    "    sps_long_term: dict[int, list[SpsLongTermReference]] | None = None,\n"
    ") -> dict[str, object]:\n",
    1,
)
text = text.replace(
    "                sps_rps,\n            )\n",
    "                sps_rps,\n"
    "                sps_long_term,\n"
    "            )\n",
    1,
)
segments.write_text(text, encoding="utf-8")

poc = Path("src/video_forensics/tools/hevc_poc.py")
text = poc.read_text(encoding="utf-8")
text = text.replace(
    "    log2_ctb_size: int\n",
    "    log2_ctb_size: int\n"
    "    long_term_ref_pics_present_flag: int = 0\n",
    1,
)
poc.write_text(text, encoding="utf-8")

hevc = Path("src/video_forensics/tools/hevc_bitstream.py")
text = hevc.read_text(encoding="utf-8")
import_line = '''from video_forensics.tools.hevc_long_term_rps import (
    parse_sps_long_term_references,
)
'''
if "from video_forensics.tools.hevc_long_term_rps import" not in text:
    anchor = "from video_forensics.tools.hevc_short_term_rps import parse_sps_short_term_rps\n"
    if anchor not in text:
        raise SystemExit("Cannot find short-term RPS import")
    text = text.replace(anchor, anchor + import_line, 1)

needle = '''    segment_analysis = parse_segment_sequence(
        rows, pps_map, sps_map, sps_rps_parsed
    )
'''
replacement = '''    sps_long_term_parsed = {}
    sps_long_term_analysis = {}
    for sps_id, short_term in sps_rps_analysis.items():
        reader_position = int(short_term["bits_consumed_through_rps"])
        source_row = next(
            row for row in rows
            if int(row["nal_unit_type"]) == 33
            and int(parse_sps_short_term_rps(bytes(row["payload"]))["sps_id"]) == sps_id
        )
        from video_forensics.tools.hevc_poc import BitReader, rbsp
        reader = BitReader(rbsp(bytes(source_row["payload"])[2:]))
        reader.position = reader_position
        parsed_long_term = parse_sps_long_term_references(
            reader,
            log2_max_poc_lsb=sps_map[sps_id].log2_max_poc_lsb,
        )
        sps_long_term_parsed[sps_id] = parsed_long_term.pop("parsed_references")
        sps_long_term_analysis[sps_id] = parsed_long_term
        sps_map[sps_id] = __import__("dataclasses").replace(
            sps_map[sps_id],
            long_term_ref_pics_present_flag=int(
                parsed_long_term["long_term_ref_pics_present_flag"]
            ),
        )
    segment_analysis = parse_segment_sequence(
        rows, pps_map, sps_map, sps_rps_parsed, sps_long_term_parsed
    )
'''
if needle not in text:
    raise SystemExit("Cannot find segment-analysis call")
text = text.replace(needle, replacement, 1)
text = text.replace(
    '''    atomic_write_json(target / "short_term_rps.json", sps_rps_analysis)
''',
    '''    atomic_write_json(target / "short_term_rps.json", sps_rps_analysis)
    atomic_write_json(target / "long_term_rps.json", sps_long_term_analysis)
''',
    1,
)
hevc.write_text(text, encoding="utf-8")
