from pathlib import Path

path = Path("tests/test_hevc_slice_segments.py")
text = path.read_text(encoding="utf-8")
needle = '''        short_term_rps=None,
'''
replacement = '''        short_term_rps=None,
        long_term_rps=None,
'''
if needle in text and "long_term_rps=None" not in text:
    text = text.replace(needle, replacement, 1)
path.write_text(text, encoding="utf-8")
