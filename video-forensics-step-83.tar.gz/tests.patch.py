from pathlib import Path

path = Path("tests/test_hevc_legacy_export.py")
text = path.read_text(encoding="utf-8")
addition = '''

def test_slice_rps_is_resolved_from_referenced_sps() -> None:
    sps_fields = {
        "sps_id": 0,
        "short_term_ref_pic_sets": [
            {"num_negative_pics": 1, "num_positive_pics": 0}
        ],
    }
    pps_fields = {"pps_id": 0, "sps_id": 0}
    source_sps = {0: sps_fields}
    pps_to_sps = {0: 0}
    item = {"nal_number": 8, "pps_id": 0, "slice_type": 1}
    enriched = dict(item)
    selected = source_sps[pps_to_sps[enriched["pps_id"]]][
        "short_term_ref_pic_sets"
    ][0]
    enriched["short_term_ref_pic_set_sps_flag"] = 1
    enriched["num_negative_pics"] = selected["num_negative_pics"]
    enriched["num_positive_pics"] = selected["num_positive_pics"]
    assert pps_fields["sps_id"] == 0
    assert enriched["short_term_ref_pic_set_sps_flag"] == 1
    assert enriched["num_negative_pics"] == 1
    assert enriched["num_positive_pics"] == 0
'''
if "test_slice_rps_is_resolved_from_referenced_sps" not in text:
    text += addition
path.write_text(text, encoding="utf-8")
