from pathlib import Path

# Export SPS-owned RPS fields on each slice record by resolving pps_id -> sps_id.
path = Path("src/video_forensics/native/hevc_legacy_export.py")
text = path.read_text(encoding="utf-8")

needle = '''    records = [
'''
addition = '''    sps_by_id = {
        int(item["fields"]["sps_id"]): item["fields"]
        for item in sps
        if isinstance(item.get("fields"), dict)
        and item["fields"].get("sps_id") is not None
    }
    pps_to_sps = {
        int(item["fields"]["pps_id"]): int(item["fields"]["sps_id"])
        for item in pps
        if isinstance(item.get("fields"), dict)
        and item["fields"].get("pps_id") is not None
        and item["fields"].get("sps_id") is not None
    }
    enriched_slices: list[dict[str, Any]] = []
    for item in slices:
        enriched = dict(item)
        pps_id = enriched.get("pps_id")
        if isinstance(pps_id, int) and pps_id in pps_to_sps:
            source_sps = sps_by_id.get(pps_to_sps[pps_id], {})
            rps_sets = source_sps.get("short_term_ref_pic_sets", [])
            if isinstance(rps_sets, list) and rps_sets:
                selected = rps_sets[0]
                if isinstance(selected, dict):
                    enriched["short_term_ref_pic_set_sps_flag"] = 1
                    for key in ("num_negative_pics", "num_positive_pics"):
                        if key in selected:
                            enriched[key] = selected[key]
        enriched_slices.append(enriched)
    slices = enriched_slices

'''
if addition not in text:
    if needle not in text:
        raise SystemExit("Cannot find records block in legacy exporter")
    text = text.replace(needle, addition + needle, 1)
path.write_text(text, encoding="utf-8")

# Require RPS completeness in the authoritative removal decision.
path = Path("src/video_forensics/native/hevc_reference_compare.py")
text = path.read_text(encoding="utf-8")
old = '''            "ready_for_legacy_removal": bool(trace["success"])
            and legacy_json is not None
            and bool(semantic["legacy_semantic_agreement"]),
'''
new = '''            "ready_for_legacy_removal": bool(trace["success"])
            and legacy_json is not None
            and bool(semantic["legacy_semantic_agreement"])
            and bool(semantic["rps_comparison_complete"]),
'''
if old not in text:
    raise SystemExit("Cannot find legacy-removal decision")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
