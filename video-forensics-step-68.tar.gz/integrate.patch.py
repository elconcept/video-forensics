from pathlib import Path

for filename in ("launchers/run_all_linux.sh", "launchers/run_all_macos.sh"):
    path = Path(filename)
    text = path.read_text(encoding="utf-8")
    marker = 'PYTHON="${PYTHON:-python}"\n'
    addition = marker + '\n"$PYTHON" scripts/bootstrap_h265nal.py\n'
    if "bootstrap_h265nal.py" not in text:
        if marker not in text:
            raise SystemExit(f"Cannot find Python marker in {path}")
        text = text.replace(marker, addition, 1)
    path.write_text(text, encoding="utf-8")

path = Path("launchers/run_all_windows.ps1")
text = path.read_text(encoding="utf-8")
marker = '$ErrorActionPreference = "Stop"\n'
addition = marker + '& $Python scripts\\bootstrap_h265nal.py\nif ($LASTEXITCODE -ne 0) { throw "h265nal bootstrap failed" }\n'
if "bootstrap_h265nal.py" not in text:
    if marker not in text:
        raise SystemExit("Cannot find Windows error policy marker")
    text = text.replace(marker, addition, 1)
path.write_text(text, encoding="utf-8")

ignore = Path(".gitignore")
value = ignore.read_text(encoding="utf-8") if ignore.exists() else ""
block = "\n# h265nal generated checkout and build\nthird_party/h265nal/\nbuild/h265nal/\n"
if "third_party/h265nal/" not in value:
    value += block
ignore.write_text(value, encoding="utf-8")
