from pathlib import Path

path = Path("pyproject.toml")
text = path.read_text(encoding="utf-8")
entry = 'video-forensics-orphan-pipeline = "video_forensics.native.orphan_pipeline:main"\n'
if entry not in text:
    anchor = 'video-forensics-libde265-run = "video_forensics.native.libde265_run:main"\n'
    if anchor not in text:
        raise SystemExit("Cannot find libde265 entry point")
    text = text.replace(anchor, anchor + entry, 1)
path.write_text(text, encoding="utf-8")
