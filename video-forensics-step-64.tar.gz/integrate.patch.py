from pathlib import Path

pyproject = Path("pyproject.toml")
text = pyproject.read_text(encoding="utf-8")
entry = 'video-forensics-cross-run-compare = "video_forensics.native.cross_run_compare:main"\n'
if entry not in text:
    marker = "[project.scripts]\n"
    if marker not in text:
        raise SystemExit("Cannot find [project.scripts]")
    text = text.replace(marker, marker + entry, 1)
pyproject.write_text(text, encoding="utf-8")

for filename in ("launchers/run_all_linux.sh", "launchers/run_all_macos.sh"):
    path = Path(filename)
    launcher = path.read_text(encoding="utf-8")
    needle = '  video-forensics-result-summary "$OUT"\n'
    replacement = needle + '  video-forensics-cross-run-compare "$RESULTS_DIR/$SAFE_STEM"\n'
    if "video-forensics-cross-run-compare" not in launcher:
        if needle not in launcher:
            raise SystemExit(f"Cannot find summary call in {path}")
        launcher = launcher.replace(needle, replacement, 1)
    path.write_text(launcher, encoding="utf-8")

path = Path("launchers/run_all_windows.ps1")
launcher = path.read_text(encoding="utf-8")
needle = '    if ($LASTEXITCODE -ne 0) { throw "summary failed for $($file.Name)" }\n'
replacement = needle + '\n    & video-forensics-cross-run-compare $fileRoot\n    if ($LASTEXITCODE -ne 0) { throw "cross-run comparison failed for $($file.Name)" }\n'
if "video-forensics-cross-run-compare" not in launcher:
    if needle not in launcher:
        raise SystemExit("Cannot find Windows summary call")
    launcher = launcher.replace(needle, replacement, 1)
path.write_text(launcher, encoding="utf-8")
