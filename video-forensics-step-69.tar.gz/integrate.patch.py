from pathlib import Path

path = Path("scripts/bootstrap_h265nal.py")
text = path.read_text(encoding="utf-8")

old = '''def build(root: Path, source: Path) -> Path:
    build_dir = root / "build/h265nal"
'''
new = '''def build(root: Path, source: Path) -> tuple[Path, Path]:
    build_dir = root / "build/h265nal"
'''
if old not in text:
    raise SystemExit("Cannot find build function")
text = text.replace(old, new, 1)

old = '''    if binary is None:
        raise FileNotFoundError("built h265nal binary not found")
    return binary.resolve()
'''
new = '''    if binary is None:
        raise FileNotFoundError("built h265nal binary not found")

    wrapper_source = root / "native/h265nal_json_wrapper"
    wrapper_build = root / "build/h265nal_json_wrapper"
    command([
        "cmake", "-S", str(wrapper_source), "-B", str(wrapper_build),
        "-DCMAKE_BUILD_TYPE=Release",
    ])
    command(["cmake", "--build", str(wrapper_build), "--config", "Release"])
    wrapper_candidates = [
        wrapper_build / "bin/h265nal_json_wrapper",
        wrapper_build / "bin/h265nal_json_wrapper.exe",
        wrapper_build / "bin/Release/h265nal_json_wrapper.exe",
        wrapper_build / "Release/h265nal_json_wrapper.exe",
    ]
    wrapper = next((item for item in wrapper_candidates if item.is_file()), None)
    if wrapper is None:
        raise FileNotFoundError("built h265nal JSON wrapper not found")
    return binary.resolve(), wrapper.resolve()
'''
if old not in text:
    raise SystemExit("Cannot find h265nal binary return block")
text = text.replace(old, new, 1)

text = text.replace(
    "    binary = build(repository, source)\n",
    "    binary, wrapper = build(repository, source)\n",
    1,
)
text = text.replace(
    '        "binary": str(binary),\n',
    '        "binary": str(binary),\n        "json_wrapper": str(wrapper),\n',
    1,
)
path.write_text(text, encoding="utf-8")

ignore = Path(".gitignore")
value = ignore.read_text(encoding="utf-8") if ignore.exists() else ""
if "build/h265nal_json_wrapper/" not in value:
    value += "build/h265nal_json_wrapper/\n"
ignore.write_text(value, encoding="utf-8")
