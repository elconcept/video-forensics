from pathlib import Path

linux = Path("launchers/bootstrap_linux.sh")
text = linux.read_text(encoding="utf-8")
text = text.replace(
    "REQUIRED_PACKAGES=(python3 python3-venv python3-pip ffmpeg)",
    "REQUIRED_PACKAGES=(python3 python3-venv python3-pip ffmpeg git cmake g++ make)",
)
text = text.replace(
    "has ffmpeg || missing_required+=(ffmpeg)",
    "has ffmpeg || missing_required+=(ffmpeg)\nhas git || missing_required+=(git)\nhas cmake || missing_required+=(cmake)\nhas g++ || missing_required+=(g++)\nhas make || missing_required+=(make)",
)
linux.write_text(text, encoding="utf-8")

macos = Path("launchers/bootstrap_macos.sh")
text = macos.read_text(encoding="utf-8")
text = text.replace(
    "required_formulae=(python@3.12 ffmpeg)",
    "required_formulae=(python@3.12 ffmpeg git cmake)",
)
macos.write_text(text, encoding="utf-8")

windows = Path("launchers/bootstrap_windows.ps1")
text = windows.read_text(encoding="utf-8")
anchor = 'Install-PackageFallback "ffmpeg" "Gyan.FFmpeg" "ffmpeg" $true\n'
addition = (
    anchor
    + 'Install-PackageFallback "git" "Git.Git" "git" $true\n'
    + 'Install-PackageFallback "cmake" "Kitware.CMake" "cmake" $true\n'
)
if 'Install-PackageFallback "git" "Git.Git" "git" $true' not in text:
    if anchor not in text:
        raise SystemExit("Cannot find Windows FFmpeg package anchor")
    text = text.replace(anchor, addition, 1)
windows.write_text(text, encoding="utf-8")
