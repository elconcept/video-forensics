from pathlib import Path

path = Path("pyproject.toml")
text = path.read_text(encoding="utf-8")
entry = 'video-forensics-h265nal = "video_forensics.native.h265nal_adapter:main"\n'
if entry not in text:
    marker = "[project.scripts]\n"
    if marker not in text:
        raise SystemExit("Cannot find [project.scripts]")
    text = text.replace(marker, marker + entry, 1)
path.write_text(text, encoding="utf-8")
