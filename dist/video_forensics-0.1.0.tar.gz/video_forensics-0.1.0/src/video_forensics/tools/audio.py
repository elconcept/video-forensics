from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path
from time import monotonic
from typing import Any

from video_forensics.manifest import atomic_write_json, utc_now
from video_forensics.process import run_command

FFPROBE = Path("/usr/bin/ffprobe")
WINDOW_SECONDS = 1.0
ROBUST_SCORE_LIMIT = 8.0


def _float_or_none(value: object) -> float | None:
    if value in (None, "", "N/A"):
        return None
    try:
        return float(str(value))
    except ValueError:
        return None


def _probe_audio(video: Path, timeout: int) -> tuple[dict[str, Any], dict[str, object]]:
    entries = (
        "stream=index,codec_name,codec_long_name,sample_rate,channels,channel_layout,"
        "sample_fmt,time_base,start_time,duration,bit_rate:"
        "packet=stream_index,pts,dts,pts_time,dts_time,duration,duration_time,pos,size,flags"
    )
    argv = [
        str(FFPROBE),
        "-v",
        "error",
        "-select_streams",
        "a:0",
        "-show_streams",
        "-show_packets",
        "-show_entries",
        entries,
        "-print_format",
        "json",
        str(video),
    ]
    result = run_command(argv, timeout=timeout)
    if result.returncode != 0:
        diagnostic = result.stderr.strip() or result.stdout.strip() or "no diagnostic output"
        raise RuntimeError(f"ffprobe audio analysis failed ({result.returncode}): {diagnostic}")
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"ffprobe audio analysis returned invalid JSON: {exc}") from exc
    return payload, result.to_dict()


def _normalize_packets(payload: dict[str, Any]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for number, packet in enumerate(payload.get("packets", []), start=1):
        rows.append(
            {
                "packet_number": number,
                "stream_index": packet.get("stream_index"),
                "pts": packet.get("pts"),
                "dts": packet.get("dts"),
                "pts_time": _float_or_none(packet.get("pts_time")),
                "dts_time": _float_or_none(packet.get("dts_time")),
                "duration": packet.get("duration"),
                "duration_time": _float_or_none(packet.get("duration_time")),
                "position": packet.get("pos"),
                "size": _float_or_none(packet.get("size")),
                "flags": packet.get("flags"),
            }
        )
    return rows


def _timeline_findings(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    previous_pts: float | None = None
    previous_end: float | None = None
    for row in rows:
        number = int(row["packet_number"])
        pts = row["pts_time"]
        duration = row["duration_time"]
        if pts is None:
            findings.append({"kind": "missing_audio_pts", "packet_number": number})
            continue
        pts_value = float(pts)
        if previous_pts is not None and pts_value < previous_pts:
            findings.append(
                {
                    "kind": "non_monotonic_audio_pts",
                    "packet_number": number,
                    "previous_pts_time": previous_pts,
                    "pts_time": pts_value,
                }
            )
        if previous_end is not None:
            delta = pts_value - previous_end
            if abs(delta) > 0.001:
                findings.append(
                    {
                        "kind": "audio_packet_timeline_discontinuity",
                        "packet_number": number,
                        "expected_pts_time": round(previous_end, 9),
                        "pts_time": pts_value,
                        "delta_seconds": round(delta, 9),
                    }
                )
        previous_pts = pts_value
        previous_end = pts_value + float(duration or 0.0)
    return findings


def _packet_windows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    buckets: dict[int, list[float]] = {}
    for row in rows:
        pts = row["pts_time"]
        size = row["size"]
        if pts is None or size is None:
            continue
        bucket = int(float(pts) // WINDOW_SECONDS)
        buckets.setdefault(bucket, []).append(float(size))
    windows: list[dict[str, object]] = []
    for bucket, values in sorted(buckets.items()):
        windows.append(
            {
                "window_number": len(windows) + 1,
                "start_time": bucket * WINDOW_SECONDS,
                "end_time": (bucket + 1) * WINDOW_SECONDS,
                "packet_count": len(values),
                "packet_bytes": int(sum(values)),
                "packet_size_mean": round(statistics.fmean(values), 6),
                "packet_size_median": round(statistics.median(values), 6),
            }
        )
    return windows


def _size_findings(windows: list[dict[str, object]]) -> list[dict[str, object]]:
    if len(windows) < 3:
        return []
    values = [float(window["packet_bytes"]) for window in windows]
    median = statistics.median(values)
    mad = statistics.median(abs(value - median) for value in values)
    if mad == 0.0:
        return []
    scale = 1.4826 * mad
    findings: list[dict[str, object]] = []
    for window in windows:
        score = abs(float(window["packet_bytes"]) - median) / scale
        if score >= ROBUST_SCORE_LIMIT:
            findings.append(
                {
                    "kind": "audio_packet_size_regime_candidate",
                    "window_number": window["window_number"],
                    "start_time": window["start_time"],
                    "end_time": window["end_time"],
                    "packet_bytes": window["packet_bytes"],
                    "robust_score": round(score, 6),
                }
            )
    return findings


def _write_csv(path: Path, rows: list[dict[str, object]], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def analyze(video: Path, output_dir: Path, *, timeout: int = 3600) -> dict[str, object]:
    video = video.resolve(strict=True)
    if not video.is_file():
        raise ValueError(f"input is not a regular file: {video}")
    if not FFPROBE.is_file():
        raise FileNotFoundError(f"required executable not found: {FFPROBE}")

    started = monotonic()
    payload, command = _probe_audio(video, timeout)
    streams = payload.get("streams", [])
    stream = streams[0] if streams else None
    rows = _normalize_packets(payload)
    windows = _packet_windows(rows)
    findings = [*_timeline_findings(rows), *_size_findings(windows)]

    atomic_write_json(output_dir / "audio" / "raw_ffprobe.json", payload)
    _write_csv(
        output_dir / "audio" / "packets.csv",
        rows,
        [
            "packet_number",
            "stream_index",
            "pts",
            "dts",
            "pts_time",
            "dts_time",
            "duration",
            "duration_time",
            "position",
            "size",
            "flags",
        ],
    )
    _write_csv(
        output_dir / "audio" / "windows.csv",
        windows,
        [
            "window_number",
            "start_time",
            "end_time",
            "packet_count",
            "packet_bytes",
            "packet_size_mean",
            "packet_size_median",
        ],
    )
    atomic_write_json(output_dir / "audio" / "findings.json", findings)

    result: dict[str, object] = {
        "schema_version": 1,
        "stage": "audio",
        "completed_at_utc": utc_now(),
        "duration_seconds": round(monotonic() - started, 6),
        "tool": {"name": "ffprobe", "executable": str(FFPROBE)},
        "command": command,
        "applicability": "applicable" if stream else "no_audio_stream",
        "stream": stream or {},
        "method": {
            "window_seconds": WINDOW_SECONDS,
            "robust_score_limit": ROBUST_SCORE_LIMIT,
        },
        "scope": {
            "supported": "audio packet timeline and packet-size screening",
            "not_supported": "waveform, spectral, phase, ENF, splice, or crossfade authentication",
        },
        "summary": {
            "packet_count": len(rows),
            "window_count": len(windows),
            "finding_count": len(findings),
        },
        "outputs": {
            "raw_ffprobe": "audio/raw_ffprobe.json",
            "packets": "audio/packets.csv",
            "windows": "audio/windows.csv",
            "findings": "audio/findings.json",
        },
    }
    atomic_write_json(output_dir / "audio" / "audio.json", result)
    return result
