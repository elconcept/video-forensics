"""Independent forensic analysis tools."""
__version__ = "0.1.0"
