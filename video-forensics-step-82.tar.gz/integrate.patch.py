from pathlib import Path

path = Path("src/video_forensics/native/hevc_semantic_compare.py")
text = path.read_text(encoding="utf-8")

start = text.find("def compare_fields(\n")
end = text.find("\n\ndef compare(\n", start)
if start == -1 or end == -1:
    raise SystemExit("Cannot find compare_fields function")

replacement = '''def record_key(record: dict[str, Any]) -> tuple[int, str]:
    number = record.get("nal_number")
    if not isinstance(number, int):
        raise TypeError("semantic record has no integer nal_number")
    return number, str(record.get("kind", ""))


def compare_fields(
    primary: list[dict[str, Any]], legacy: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    primary_map = {record_key(item): item for item in primary}
    legacy_map = {record_key(item): item for item in legacy}
    comparisons: list[dict[str, Any]] = []
    for key in sorted(set(primary_map) | set(legacy_map)):
        left = primary_map.get(key)
        right = legacy_map.get(key)
        nal_number, kind = key
        if left is None:
            comparisons.append(
                {
                    "nal_number": nal_number,
                    "kind": kind,
                    "status": "missing_primary_record",
                    "shared_field_count": 0,
                    "mismatch_count": 0,
                    "mismatches": [],
                }
            )
            continue
        if right is None:
            comparisons.append(
                {
                    "nal_number": nal_number,
                    "kind": kind,
                    "status": "missing_legacy_record",
                    "shared_field_count": 0,
                    "mismatch_count": 0,
                    "mismatches": [],
                }
            )
            continue
        left_fields = left.get("fields", {})
        right_fields = right.get("fields", {})
        shared = sorted(set(left_fields) & set(right_fields))
        mismatches = [
            {
                "field": field,
                "primary": left_fields[field],
                "legacy": right_fields[field],
            }
            for field in shared
            if left_fields[field] != right_fields[field]
        ]
        comparisons.append(
            {
                "nal_number": nal_number,
                "kind": kind,
                "shared_fields": shared,
                "shared_field_count": len(shared),
                "mismatch_count": len(mismatches),
                "mismatches": mismatches,
                "status": "match" if shared and not mismatches else "mismatch",
            }
        )
    return comparisons
'''
text = text[:start] + replacement + text[end:]

old = '''    for item in record_comparisons:
        if item.get("shared_field_count", 0):
            left = primary_items[int(item["record_index"])]["fields"]
            right = legacy_items[int(item["record_index"])]["fields"]
            shared_keys.update(set(left) & set(right))
'''
new = '''    for item in record_comparisons:
        shared_keys.update(item.get("shared_fields", []))
'''
if old not in text:
    raise SystemExit("Cannot find index-based shared-key collection")
text = text.replace(old, new, 1)

old = '''        and len(primary_items) == len(legacy_items)
'''
new = '''        and not any(
            item["status"] in {"missing_primary_record", "missing_legacy_record"}
            for item in record_comparisons
            if item["kind"] != "vps"
        )
'''
if old not in text:
    raise SystemExit("Cannot find record-count equality rule")
text = text.replace(old, new, 1)

path.write_text(text, encoding="utf-8")
print(f"Aligned semantic records by nal_number and kind in {path}")
