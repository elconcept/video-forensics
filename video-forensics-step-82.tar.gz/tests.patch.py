from pathlib import Path

path = Path("tests/test_hevc_semantic_compare.py")
text = path.read_text(encoding="utf-8")
addition = '''

def test_records_are_aligned_by_nal_number_and_kind() -> None:
    primary_records = [
        {"nal_number": 2, "kind": "sps", "fields": {"width": 1920}},
        {"nal_number": 3, "kind": "pps", "fields": {"pps_id": 0}},
        {"nal_number": 7, "kind": "slice", "fields": {"poc_lsb": 0}},
    ]
    legacy_records = [
        {"nal_number": 2, "kind": "sps", "fields": {"width": 1920}},
        {"nal_number": 7, "kind": "slice", "fields": {"poc_lsb": 0}},
        {"nal_number": 3, "kind": "pps", "fields": {"pps_id": 0}},
    ]
    from video_forensics.native.hevc_semantic_compare import compare_fields

    result = compare_fields(primary_records, legacy_records)
    assert [item["nal_number"] for item in result] == [2, 3, 7]
    assert all(item["status"] == "match" for item in result)
    assert sum(item["mismatch_count"] for item in result) == 0


def test_missing_vps_does_not_shift_following_records() -> None:
    from video_forensics.native.hevc_semantic_compare import compare_fields

    result = compare_fields(
        [
            {"nal_number": 1, "kind": "vps", "fields": {}},
            {"nal_number": 2, "kind": "sps", "fields": {"width": 1920}},
        ],
        [{"nal_number": 2, "kind": "sps", "fields": {"width": 1920}}],
    )
    assert result[0]["status"] == "missing_legacy_record"
    assert result[1]["status"] == "match"
'''
if "test_records_are_aligned_by_nal_number_and_kind" not in text:
    text += addition
path.write_text(text, encoding="utf-8")
