from pathlib import Path

path = Path("pyproject.toml")
text = path.read_text(encoding="utf-8")
entry = 'video-forensics-hevc-semantic-compare = "video_forensics.native.hevc_semantic_compare:main"\n'
if entry not in text:
    marker = "[project.scripts]\n"
    if marker not in text:
        raise SystemExit("Cannot find [project.scripts]")
    text = text.replace(marker, marker + entry, 1)
path.write_text(text, encoding="utf-8")
